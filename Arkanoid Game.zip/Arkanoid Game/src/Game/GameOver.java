package Game;

import java.awt.*;
import java.awt.event.*;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.TreeMap;

import javax.swing.*;

public class GameOver extends NewGame  implements KeyListener{
	
	private JFrame GameOverWindow;
	
	public GameOver() {
		
		GameOverWindow = new JFrame();
		GameOverWindow.setLayout(null);
		
		int GameOverWidth = 500;
		int GameOverHeight = 700; 
		
		GameOverWindow.setBounds(550, 80, GameOverWidth, GameOverHeight); 
		
		GameOverWindow.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		
		Image icon = Toolkit.getDefaultToolkit().getImage("Asl�.jpg");    
		GameOverWindow.setIconImage(icon);  
		
		JPanel GameOver = new JPanel();
		GameOver.setBackground(Color.BLACK);
		GameOver.setBounds(0, 0, GameOverWidth, GameOverHeight);
		GameOverWindow.add(GameOver);
		GameOver.setLayout(null);
		
		
		JTextArea gameOver= new JTextArea("GAME OVER!");
		gameOver.setFont(new Font("Helvatica", Font.PLAIN, 40));
		gameOver.setBounds(120, 150, 300, 100);
		gameOver.setOpaque(false);
		gameOver.setEditable(false);
		GameOver.add(gameOver);
		
		JTextArea Name= new JTextArea("Name: ");
		Name.setFont(new Font("Helvatica", Font.BOLD, 20));
		Name.setBounds(120, 250, 200, 100);
		Name.setOpaque(false);
		Name.setEditable(true);
		GameOver.add(Name);
		
		JButton newGame = new JButton("New Game");
		newGame.setBounds(200, 400, 100, 50);
		newGame.setOpaque(true);
		newGame.setBackground(Color.white);
		GameOver.add(newGame);
		
			
		GameOverWindow.setVisible(true);
		GameOverWindow.setResizable(false);
		GameOverWindow.addKeyListener(this);
		
		newGame.addActionListener(new ActionListener() {	
			@Override
			public void actionPerformed(ActionEvent a) {
				new NewGame();

					FileWriter writer;
				    try {
				    	
				      writer = new FileWriter("Scores.txt",true);
				      writer.write(Name.getText()+ " - "+score);
				      writer.write("\n");
				      writer.close();
				      
				    } catch (IOException e) {    	
				    	e. printStackTrace();
				    }

				score = 0;
				lives = 3;
				
				}
		});
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyPressed(KeyEvent e) {
		
		if(e.isControlDown() && e.getKeyCode() == KeyEvent.VK_Q){	
			System.exit(0);
		}
		
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}
	
	public int scoreComparator(int score) {
		return this.score-score;
	}
	
}

