package Game;

import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.*;

public class Options  implements KeyListener{

	private JFrame optionsWindow;
	
	public Options() {
		
		optionsWindow = new JFrame("Options");
		optionsWindow.setLayout(null);
		
		int optionsWidth = 500;
		int optionsHeight = 700; 
		
		optionsWindow.setBounds(550, 80, optionsWidth, optionsHeight); 
		
		optionsWindow.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		
		Image icon = Toolkit.getDefaultToolkit().getImage("Asl�.jpg");    
		optionsWindow.setIconImage(icon);  
		
		JLabel background = new JLabel(new ImageIcon("Options.jpg"));
		optionsWindow.add(background);
		background.setBounds(0, 0, optionsWidth, optionsHeight);
		background.setLayout(null);
			
		optionsWindow.setVisible(true);
		optionsWindow.setResizable(false);
		optionsWindow.addKeyListener(this);
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyPressed(KeyEvent e) {
		
		if(e.isControlDown() && e.getKeyCode() == KeyEvent.VK_Q){	
			System.exit(0);
		}
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

}
