package Game;

import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import javax.swing.*;

public class Level3 extends NewGame implements KeyListener,ActionListener {
	 
	 private boolean start1 = false;
	 private JLabel Ball;
	 private JLabel Paddle;
	 private JLabel background;
	 public JLabel Score;
	 public JLabel Lives;
	 private int xActor = 50;
	 private int yActor = 570;
	 private Timer timer;
	 private int delay = 8;
	 private int ballPositionX = 100;
	 private int ballPositionY = 350;
	 private int dirX = -2;
	 private int dirY = -4;
	 public int brickcount = 18;
	 private JFrame level3Window;
	 ArrayList<JLabel> Bricks = new ArrayList<JLabel>();
	 private JLabel brick1, brick2, brick3, brick4, brick5, brick6, brick7, brick8, brick9, brick10,
	 brick11, brick12, brick13, brick14, brick15, brick16, brick17, brick18;
	 Map<JLabel, Integer> brickValues  = new HashMap<>();

	public Level3() {
		
		level3Window = new JFrame();
		level3Window.setLayout(null);
		
		int level3Width = 500;
		int level3Height = 700; 
		
		
		level3Window.setBounds(550, 80, level3Width, level3Height); 
		
		level3Window.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		
		Image icon = Toolkit.getDefaultToolkit().getImage("Asl�.jpg");    
		level3Window.setIconImage(icon);  
		
		
		background = new JLabel(new ImageIcon("Level3.png"));
		level3Window.add(background);
		background.setBounds(0, 0, level3Width, level3Height);
		background.setLayout(null);
			
		level3Window.setVisible(true);
		level3Window.setResizable(false);
		
		//Score	
		Score = new JLabel("Score: " + score); 
		Score.setFont(new Font("Helvatica", Font.BOLD, 16));
		Score.setBounds(15, 15, 100, 15); 
		Score.setForeground (Color.white);
		background.add(Score);
				
		//Level	
		JLabel Level = new JLabel("Level 3"); 
		Level.setFont(new Font("Helvatica", Font.BOLD, 16));
		Level.setBounds(220, 15, 100, 15);  
		Level.setForeground (Color.white);
		background.add(Level);
				
		//Lives	
		Lives = new JLabel("Lives: " + lives); 
		Lives.setFont(new Font("Helvatica", Font.BOLD, 16));
		Lives.setBounds(410, 15, 100, 15); 
		Lives.setForeground (Color.white);
		background.add(Lives);
		
		// Ball
		ImageIcon ball = new ImageIcon("TheBall.png");
		Ball = new JLabel(ball);  
		Ball.setBounds(ballPositionX, ballPositionY, 25, 25);    
		background.add(Ball);   
		
		// Paddle
		ImageIcon paddle = new ImageIcon("paddle.png");
		Paddle = new JLabel(paddle);  
		Paddle.setBounds(xActor, yActor, 110, 20);    
		background.add(Paddle);  
		
		// Bricks
		ImageIcon wbrick = new ImageIcon("wbrick.png");
		ImageIcon lbrick = new ImageIcon("lbrick.png");
		ImageIcon bbrick = new ImageIcon("bbrick.png");
		
		brick1 = new JLabel(bbrick);
		brick1.setBounds(37, 100, 66, 35);    
		background.add(brick1);
		
		brick2 = new JLabel(bbrick);
		brick2.setBounds(108, 100, 66, 35);    
		background.add(brick2);
		
		brick3 = new JLabel(bbrick);
		brick3.setBounds(179, 100, 66, 35);    
		background.add(brick3);
		
		brick4 = new JLabel(bbrick);
		brick4.setBounds(250, 100, 66, 35);    
		background.add(brick4);
		
		brick5 = new JLabel(bbrick);
		brick5.setBounds(321, 100, 66, 35);    
		background.add(brick5);
		
		brick6 = new JLabel(bbrick);
		brick6.setBounds(392, 100, 66, 35);    
		background.add(brick6);
		//
		brick7 = new JLabel(lbrick);
		brick7.setBounds(37, 140, 66, 35);    
		background.add(brick7);
		
		brick8 = new JLabel(lbrick);
		brick8.setBounds(108, 140, 66, 35);    
		background.add(brick8);
		
		brick9 = new JLabel(lbrick);
		brick9.setBounds(179, 140, 66, 35);    
		background.add(brick9);
		
		brick10 = new JLabel(lbrick);
		brick10.setBounds(250, 140, 66, 35);    
		background.add(brick10);
		
		brick11 = new JLabel(lbrick);
		brick11.setBounds(321, 140, 66, 35);    
		background.add(brick11);
		
		brick12 = new JLabel(lbrick);
		brick12.setBounds(392, 140, 66, 35);    
		background.add(brick12);
		//
		brick13 = new JLabel(wbrick);
		brick13.setBounds(37, 180, 66, 35);    
		background.add(brick13);
		
		brick14 = new JLabel(wbrick);
		brick14.setBounds(108, 180, 66, 35);    
		background.add(brick14);
		
		brick15 = new JLabel(wbrick);
		brick15.setBounds(179, 180, 66, 35);    
		background.add(brick15);
		
		brick16 = new JLabel(wbrick);
		brick16.setBounds(250, 180, 66, 35);    
		background.add(brick16);
		
		brick17 = new JLabel(wbrick);
		brick17.setBounds(321, 180, 66, 35);    
		background.add(brick17);
		
		brick18 = new JLabel(wbrick);
		brick18.setBounds(392, 180, 66, 35);    
		background.add(brick18);
		
		Bricks.add(brick1);
		Bricks.add(brick2);
		Bricks.add(brick3);
		Bricks.add(brick4);
		Bricks.add(brick5);
		Bricks.add(brick6);
		Bricks.add(brick7);
		Bricks.add(brick8);
		Bricks.add(brick9);
		Bricks.add(brick10);
		Bricks.add(brick11);
		Bricks.add(brick12);
		Bricks.add(brick13);
		Bricks.add(brick14);
		Bricks.add(brick15);
		Bricks.add(brick16);
		Bricks.add(brick17);
		Bricks.add(brick18);
		
		for(JLabel brick : Bricks) {
			
			if(brick.getY() == 100) {
				brickValues.put(brick,3);
			}
			
			if(brick.getY() == 140 ) {
				brickValues.put(brick,2);
			
			}
			if(brick.getY() == 180) {
				brickValues.put(brick,1);
			}
		}
		
		level3Window.addKeyListener(this);
		
		timer = new Timer(delay , this);
		timer.start();
	}
	
	public void movePaddle(int newX,int newY) {
		Paddle.setBounds(newX, newY, 110, 20); 
	  }
	
	public void newLocationBall (int newX, int newY) {
		Ball.setBounds(newX, newY, 25, 25);
	}
	
	public void changeLayoutLeft(){
		
		start1 = true;
		if(xActor > 0){
		xActor-= 20;	
		movePaddle(xActor,yActor);	
		
		}else {  xActor = xActor;  }
	}
	public void changeLayoutRight(){
		
		start1 = true;
		if(xActor < 372) {
		xActor += 20;
		movePaddle(xActor,yActor);
		
		}else { xActor = xActor; } 
	}


	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyPressed(KeyEvent e) {
		
		String keyevent =KeyEvent.getKeyText(e.getKeyCode());
		
		if(keyevent.equals("Left")){
			changeLayoutLeft();
			
		}else if(keyevent.equals("Right")){
			changeLayoutRight();
			
		}if(e.isControlDown() && e.getKeyCode() == KeyEvent.VK_Q){	
			System.exit(0);
		}	
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
		timer.start();
		if(start1) {
			
			if(new Rectangle(ballPositionX, ballPositionY, 25, 25).intersects(new Rectangle(xActor, yActor, 110, 20))){
				dirY = -dirY;
				
			}try {
			
				for(JLabel brick : Bricks) {
					
					if(new Rectangle(ballPositionX, ballPositionY, 25, 25).intersects(brick.getX(), brick.getY(), 66, 35)) {
					
						for (Iterator<Entry<JLabel, Integer>> iterator = brickValues.entrySet().iterator(); iterator.hasNext();) {
						
							Entry<JLabel, Integer> m = iterator.next();
						
							if(m.getKey()== brick && m.getValue()== 3){
								brickValues.replace(brick,2);
								dirY = -dirY;
								score += 10;
								Score.setText("Score: "+ score);
								
							}else if(m.getKey()== brick && m.getValue()== 2){
								brickValues.replace(brick,1);
								dirY = -dirY;
								score += 10;
								Score.setText("Score: "+ score);
							
							}else if (m.getKey()== brick && m.getValue() == 1){
							
								brickValues.remove(brick);
								background.remove(brick);
								background.repaint();
								dirY = -dirY;
								Bricks.remove(brick);
								brickcount --;
								score += 10;
								Score.setText("Score: "+ score);		
							}
						}
					}
				}
				
			}catch(Exception a){
				
			}
			ballPositionX += dirX;
			ballPositionY += dirY;
			
			if(ballPositionX < 0) {
				dirX = -dirX;
			}
			if(ballPositionY < 0) {
				dirY = -dirY;
			}
			if (ballPositionX > 465) {
				dirX = -dirX;
			}
			if (ballPositionY > 700) {
				start1 = false;
				ballPositionX = 100;
				ballPositionY = 350;
				lives --;
				Lives.setText("Lives: "+ lives);
			}
			if(lives == 0) {
				timer.stop();
				new GameOver();
				
			}
			if (brickcount == 0 && lives > 0) {
				timer.stop();
				new GameOver();
				
			}
		}
		newLocationBall(ballPositionX,ballPositionY);
		
	}
}
