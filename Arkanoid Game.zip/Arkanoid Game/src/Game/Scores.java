package Game;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.Scanner;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextArea;

public class Scores  implements KeyListener{

	private JFrame scoreWindow;
	private String scoreList;
	
	public Scores() {
		
		scoreWindow = new JFrame("Scores");
		scoreWindow.setLayout(null);
		
		int scoreWidth = 500;
		int scoreHeight = 700; 
		
		scoreWindow.setBounds(550, 80, scoreWidth, scoreHeight);
		
		scoreWindow.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		
		Image icon = Toolkit.getDefaultToolkit().getImage("Asl�.jpg");    
		scoreWindow.setIconImage(icon);  
		
		JLabel background = new JLabel(new ImageIcon("Score.jpg"));
		scoreWindow.add(background);
		background.setBounds(0, 0, scoreWidth, scoreHeight);
		background.setLayout(null);
		
		JTextArea scoreText= new JTextArea();
		scoreText.setEditable(false);
		scoreText.setBounds(55,55,450,450);
		background.add(scoreText);
		scoreText.setOpaque(false);
		scoreText.setFont(new Font("Helvatica", Font.PLAIN, 15));
		scoreText.setForeground (Color.white);
			
		scoreWindow.setVisible(true);
		scoreWindow.setResizable(false);
		scoreWindow.addKeyListener(this);
		
		try {
			FileInputStream fstream = new FileInputStream("Scores.txt");
			BufferedReader br = new BufferedReader(new InputStreamReader(fstream));
			String strLine;
			
			int flag = 0;
			
			while ((strLine = br.readLine()) != null) {
				
				scoreList = strLine +"\n"
						+ scoreList;
				flag++;
				if(flag == 10) { break;}
			}	
			
			br.close();
			scoreText.setText("High Scores\n"
					+"\n" +scoreList);
			
		} catch (Exception e) {
			System.err.println("Error: " + e.getMessage());
		}
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyPressed(KeyEvent e) {
		
		if(e.isControlDown() && e.getKeyCode() == KeyEvent.VK_Q){	
			System.exit(0);
		}
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

}
