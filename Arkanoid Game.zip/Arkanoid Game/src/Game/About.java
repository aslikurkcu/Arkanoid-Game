package Game;

import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.*;

public class About  implements KeyListener{

	private JFrame aboutWindow;
	
	public About() {
		
		aboutWindow = new JFrame("About");
		aboutWindow.setLayout(null);
		
		int aboutWidth = 500;
		int aboutHeight = 700; 
		
		aboutWindow.setBounds(550, 80, aboutWidth, aboutHeight); 
		
		aboutWindow.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		
		Image icon = Toolkit.getDefaultToolkit().getImage("Asl�.jpg");    
		aboutWindow.setIconImage(icon);
		
		JLabel background = new JLabel(new ImageIcon("About.jpg"));
		aboutWindow.add(background);
		background.setBounds(0, 0, aboutWidth, aboutHeight);
		background.setLayout(null);
			
		JLabel name = new JLabel("Raziye Asl�han K�RKC�");
		background.add(name);
		name.setBounds(120,150,200,50);
		
		JLabel id = new JLabel("20190702001");
		background.add(id);
		id.setBounds(120,200,200,50);
		
		JLabel email = new JLabel("raziyeaslihan.kurkcu@std.yeditepe.edu.tr");
		background.add(email);
		email.setBounds(120,250,400,50);
		
		
		aboutWindow.setVisible(true);
		aboutWindow.setResizable(false);
		aboutWindow.addKeyListener(this);
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyPressed(KeyEvent e) {
		
		if(e.isControlDown() && e.getKeyCode() == KeyEvent.VK_Q){	
			System.exit(0);
		}
		
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

}
