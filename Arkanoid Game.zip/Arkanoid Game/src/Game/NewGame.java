package Game;

import java.awt.Color;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.*;

public class NewGame implements KeyListener{
	
	 public static int score = 0;
	 public static int lives = 3;
	 private JFrame gameWindow;

	public NewGame() {
		
		gameWindow = new JFrame("New Game");
		gameWindow.setLayout(null);
		
		int gameWidth = 500;
		int gameHeight = 700; 
		
		gameWindow.setBounds(550, 80, gameWidth, gameHeight); 
		
		gameWindow.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		
		Image icon = Toolkit.getDefaultToolkit().getImage("Asl�.jpg");    
		gameWindow.setIconImage(icon);  
		
		JLabel background = new JLabel(new ImageIcon("NewGame.jpg"));
		gameWindow.add(background);
		background.setBounds(0, 0, gameWidth, gameHeight);
		background.setLayout(null);
		
		JButton b1 = new JButton("Level 1");
		b1.setBounds(200, 160, 100, 50);
		b1.setOpaque(true);
		b1.setBackground(Color.white);
		
		
		JButton b2 = new JButton("Level 2");
		b2.setBounds(200, 280, 100, 50);
		b2.setOpaque(true);
		b2.setBackground(Color.white);
		
		
		JButton b3 = new JButton("Level 3");
		b3.setBounds(200, 400, 100, 50);
		b3.setOpaque(true);
		b3.setBackground(Color.white);
		
		background.add(b1);
        background.add(b2);
        background.add(b3);
			
		gameWindow.setVisible(true);
		gameWindow.setResizable(false);
		
		
		b1.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent a) {
				new Level1();
				
			}
		});
		
		b2.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent a) {
				new Level2();
				
			}
		});
		
		b3.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent a) {
				new Level3();
				
			}
		});
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyPressed(KeyEvent e) {
		
		if(e.isControlDown() && e.getKeyCode() == KeyEvent.VK_Q){	
			System.exit(0);
		}
		
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

}
