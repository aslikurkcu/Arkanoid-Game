package Game;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class MainMenu implements KeyListener{
	
	private JFrame mainWindow;
	
	public MainMenu() {
		
		mainWindow = new JFrame("Arkanoid Game");
		mainWindow.setLayout(null);
		
		int windowWidth = 500;
		int windowHeight = 700; 
		
		mainWindow.setBounds(550, 80, windowWidth, windowHeight); 
		
		mainWindow.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		Image icon = Toolkit.getDefaultToolkit().getImage("Asl�.jpg");    
		mainWindow.setIconImage(icon);    
		
		JLabel background = new JLabel(new ImageIcon("Menu.jpg"));
		mainWindow.add(background);
		background.setBounds(0, 0, windowWidth, windowHeight);
		background.setLayout(null);
		
		
		JButton b1 = new JButton("New Game");
		b1.setBounds(200, 60, 100, 50);
		b1.setOpaque(true);
		b1.setBackground(Color.white);
		
		
		JButton b2 = new JButton("Options");
		b2.setBounds(200, 160, 100, 50);
		b2.setOpaque(true);
		b2.setBackground(Color.white);
		
		
		JButton b3 = new JButton("Scores");
		b3.setBounds(200, 260, 100, 50);
		b3.setOpaque(true);
		b3.setBackground(Color.white);
		
		
		JButton b4 = new JButton("Help");
		b4.setBounds(200, 360, 100, 50);
		b4.setOpaque(true);
		b4.setBackground(Color.white);
		
		
		JButton b5 = new JButton("About");
		b5.setBounds(200, 460, 100, 50);
		b5.setOpaque(true);
		b5.setBackground(Color.white);
	
		
		JButton b6 = new JButton("Exit");
		b6.setBounds(200, 560, 100, 50);
		b6.setOpaque(true);
		b6.setBackground(Color.white);
		
		
        background.add(b1);
        background.add(b2);
        background.add(b3);
        background.add(b4);
        background.add(b5);
        background.add(b6);
        
        mainWindow.setVisible(true);
		mainWindow.setResizable(false);
		mainWindow.addKeyListener(this);
	
		b1.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent a) {
				new NewGame();
			}
		});
		
		b2.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent a) {
				new Options();
			}
		});
		
		b3.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent a) {
				new Scores();
			}
		});
		
		b4.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent a) {
				new Help();
				
			}
		});
		
		b5.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent a) {
				new About();
			}
		});
		
		b6.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent a) {
				System.exit(0);
			}
		});
		
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyPressed(KeyEvent e) {
		
		if(e.isControlDown() && e.getKeyCode() == KeyEvent.VK_Q){	
			System.exit(0);
		}
		
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}
}


