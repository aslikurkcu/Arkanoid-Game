package Game;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.*;

public class Help  implements KeyListener{
	
	private JFrame helpWindow;

	public Help() {
		
		helpWindow = new JFrame("Help");
		helpWindow.setLayout(null);
		
		int helpWidth = 500;
		int helpHeight = 700; 
		
		helpWindow.setBounds(550, 80, helpWidth, helpHeight); 
		
		helpWindow.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		
		Image icon = Toolkit.getDefaultToolkit().getImage("Asl�.jpg");    
		helpWindow.setIconImage(icon);  
		
		JLabel background = new JLabel(new ImageIcon("Help.jpg"));
		helpWindow.add(background);
		background.setBounds(0, 0, helpWidth, helpHeight);
		background.setLayout(null);
		
		JTextArea helpText= new JTextArea("# In this game, the player should slide the paddle left and right \n"
				+ "using the left-right keys on the keyboard to bounce the ball.\n"
				+ "# There are 3 levels in the game.\n"
				+ "# The player should break all bricks to move on to the next level.\n"
				+ "# White bricks break with 1 hit.\n"
				+ "# Lilac bricks break with 2 hits.\n"
				+ "# Blue bricks break with 3 hits.\n"
				+ "# The player has 3 lives.\n"
				+ "# If the player cannot catch the ball, loses 1 live.\n"
				+ "# If the player does not have any lives the game is over.\n",10,30);
		
		helpText.setEditable(false);
		helpText.setBounds(45,50,450,450);
		background.add(helpText);
		helpText.setOpaque(false);
		helpText.setFont(new Font("Helvatica", Font.PLAIN, 14));
			
		helpWindow.setVisible(true);
		helpWindow.setResizable(false);
		helpWindow.addKeyListener(this);
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyPressed(KeyEvent e) {
		
		if(e.isControlDown() && e.getKeyCode() == KeyEvent.VK_Q){	
			System.exit(0);
		}
		
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

}
